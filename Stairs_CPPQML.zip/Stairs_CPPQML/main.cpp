/************************************************/
/* - Serial-Read RFID, Start-time, Stop-time    */
/* - Connect to the LoRa Network and get        */
/*   the values (RFID, timestamps)              */
/* - Store the values in the database           */
/* - Interface the QML file with C++ objects    */
/* - Plot the database in the QML file          */
/************************************************/

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlListProperty>
#include <QQmlContext>
#include <QQmlComponent>

#include <QEvent>
#include <QObject>
#include <QDebug>

#include <QNetworkAccessManager>
#include <QUrl>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

/*
class RFID
{
public:
    QString rf_ID;
    QString start_Time;
    QString stop_Time;
    QString time_lapsed;
};
*/
class Message : public QObject
{
//    Q_OBJECT
    Q_PROPERTY(QString author READ author WRITE setAuthor NOTIFY authorChanged)
public:
    void setAuthor(const QString &a) {
        if (a != m_author) {
            m_author = a;
            emit authorChanged();
        }
    }
    QString author() const {
        return m_author;
    }
signals:
    void authorChanged();
private:
    QString m_author;

//virtual ~Message() {}
};


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

/*  Connect to the LoRa network with DEVICE_ADDR or the Node EUI */
    QUrl lora_url("http://thethingsnetwork.org/api/v0/nodes/05060708/");

/* Connect-Request with user-id, password *//*
    QNetworkRequest lora_request(lora_url);
    lora_request.setRawHeader("user-name", "usr-id:password");
*/

    QNetworkAccessManager *manager = new QNetworkAccessManager();
    QEventLoop loop;

    QObject::connect(manager, SIGNAL (finished (QNetworkReply*)), &loop, SLOT(quit()));

    QNetworkReply *reply = manager->get(lora_request);
    loop.exec();

    QString response = (QString)reply->readAll();

    qDebug() << response;

    QJsonDocument temp = QJsonDocument::fromJson(response.toUtf8());
    QJsonObject jsonObj = temp.object();

    int count = jsonObj["count"].toInt();
    QString next = jsonObj["next"].toString();
    QString previous = jsonObj["previous"].toString();

    QJsonArray project_list = jsonObj["results"].toArray();

    QQmlListProperty<QStringList> data;

    for(int i = 0; i < count; i++)
    {
        QJsonObject value = project_list[i].toObject();
        QStringList result;

        result.append(value["rf_ID"].toString());
        result.append(value["start_Time"].toString());
        result.append(value["stop_Time"].toString());

//gives error & does not append to the data
//data.qlist_append(data, result);
    }

/* create a root context, API authentication, project context */
// instantiate objects using QQuiComponent and place them in QQuickWindow
// subclass QQuickWindow and setup a constructor

/*
    QQmlEngine engine1;
    QQmlContext project_context(engine1.rootContext());
    engine1.rootContext()->setContextProperty("project_list", &data);
    QQmlComponent component(&engine1, QUrl::fromLocalFile("StairsView.qml"));
    component.create();
*/

/*
    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
*/

    QQmlEngine engine2;
    Message msg;
    engine2.rootContext()->setContextProperty("msg", &msg);
    QQmlComponent component(&engine2, QUrl::fromLocalFile("qrc:/main.qml"));
    component.create();


    return app.exec();
}
