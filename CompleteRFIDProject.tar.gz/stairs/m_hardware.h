#ifndef M_HARDWARE_H
#define M_HARDWARE_H

#include <QObject>

class QSqlDatabase;

class m_hardware : public QObject
{
    Q_OBJECT
public:
    explicit m_hardware(QObject *parent = 0);

signals:
    void bufferResponse(const QByteArray &data);

public slots:
    void registerStation(const QString &hwd_id,
                         const QString &description);
    void registerRFID(const QString &rfid_tag,
                      const QString &firstname,
                      const QString &lastname);
    void registerConditions(const QString &hwd_id_from,
                            const QString &hwd_id_to,
                            const float distanceMeters,
                            const float kcal);
    void setDB(const QSqlDatabase &db) {m_db = &db;}
    void getAllStations();
    void getAllRfids();

private:
    const QSqlDatabase *m_db;
    QByteArray data;
};

#endif // M_HARDWARE_H
