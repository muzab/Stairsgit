/********************************************************************************
** Form generated from reading UI file 'hwdwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HWDWINDOW_H
#define UI_HWDWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HWdWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTableView *stations;
    QGroupBox *groupBox;
    QLabel *label;
    QPushButton *sendStationButton;
    QLineEdit *hwd_id;
    QLabel *label_2;
    QLineEdit *description;
    QPushButton *updateStations;
    QWidget *tab_2;
    QTableView *rfids;
    QGroupBox *groupBox_2;
    QPushButton *sendRfidButton;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *rfid_tag;
    QLineEdit *firstname;
    QLineEdit *lastname;
    QPushButton *updateRfids;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *HWdWindow)
    {
        if (HWdWindow->objectName().isEmpty())
            HWdWindow->setObjectName(QStringLiteral("HWdWindow"));
        HWdWindow->resize(404, 338);
        centralWidget = new QWidget(HWdWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 381, 271));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        stations = new QTableView(tab);
        stations->setObjectName(QStringLiteral("stations"));
        stations->setGeometry(QRect(0, 0, 381, 131));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(0, 130, 371, 80));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 20, 47, 13));
        sendStationButton = new QPushButton(groupBox);
        sendStationButton->setObjectName(QStringLiteral("sendStationButton"));
        sendStationButton->setGeometry(QRect(290, 10, 75, 61));
        hwd_id = new QLineEdit(groupBox);
        hwd_id->setObjectName(QStringLiteral("hwd_id"));
        hwd_id->setGeometry(QRect(100, 20, 171, 20));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 50, 80, 16));
        description = new QLineEdit(groupBox);
        description->setObjectName(QStringLiteral("description"));
        description->setGeometry(QRect(100, 50, 171, 20));
        updateStations = new QPushButton(tab);
        updateStations->setObjectName(QStringLiteral("updateStations"));
        updateStations->setGeometry(QRect(260, 100, 111, 23));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        rfids = new QTableView(tab_2);
        rfids->setObjectName(QStringLiteral("rfids"));
        rfids->setGeometry(QRect(0, 0, 381, 111));
        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(0, 109, 371, 101));
        sendRfidButton = new QPushButton(groupBox_2);
        sendRfidButton->setObjectName(QStringLiteral("sendRfidButton"));
        sendRfidButton->setGeometry(QRect(254, 20, 81, 61));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 20, 60, 13));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 50, 80, 16));
        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 80, 80, 16));
        rfid_tag = new QLineEdit(groupBox_2);
        rfid_tag->setObjectName(QStringLiteral("rfid_tag"));
        rfid_tag->setGeometry(QRect(90, 20, 113, 20));
        firstname = new QLineEdit(groupBox_2);
        firstname->setObjectName(QStringLiteral("firstname"));
        firstname->setGeometry(QRect(90, 50, 113, 20));
        lastname = new QLineEdit(groupBox_2);
        lastname->setObjectName(QStringLiteral("lastname"));
        lastname->setGeometry(QRect(90, 80, 113, 20));
        updateRfids = new QPushButton(tab_2);
        updateRfids->setObjectName(QStringLiteral("updateRfids"));
        updateRfids->setGeometry(QRect(270, 80, 101, 23));
        tabWidget->addTab(tab_2, QString());
        HWdWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(HWdWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 404, 31));
        HWdWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(HWdWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        HWdWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(HWdWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        HWdWindow->setStatusBar(statusBar);

        retranslateUi(HWdWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(HWdWindow);
    } // setupUi

    void retranslateUi(QMainWindow *HWdWindow)
    {
        HWdWindow->setWindowTitle(QApplication::translate("HWdWindow", "HWdWindow", 0));
        groupBox->setTitle(QApplication::translate("HWdWindow", "Manual Input", 0));
        label->setText(QApplication::translate("HWdWindow", "Hwd Id", 0));
        sendStationButton->setText(QApplication::translate("HWdWindow", "Send\n"
"to Stairs\n"
"+Assign ID", 0));
        label_2->setText(QApplication::translate("HWdWindow", "Description", 0));
        updateStations->setText(QApplication::translate("HWdWindow", "update stations", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("HWdWindow", "Stations", 0));
        groupBox_2->setTitle(QApplication::translate("HWdWindow", "Manual Input", 0));
        sendRfidButton->setText(QApplication::translate("HWdWindow", "Send\n"
"to Stairs\n"
"+Assign ID", 0));
        label_3->setText(QApplication::translate("HWdWindow", "Rfid Tag", 0));
        label_4->setText(QApplication::translate("HWdWindow", "First Name", 0));
        label_5->setText(QApplication::translate("HWdWindow", "Last Name", 0));
        updateRfids->setText(QApplication::translate("HWdWindow", "update rfids", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("HWdWindow", "Rfids", 0));
    } // retranslateUi

};

namespace Ui {
    class HWdWindow: public Ui_HWdWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HWDWINDOW_H
