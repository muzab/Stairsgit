/********************************************************************************
** Form generated from reading UI file 'logwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGWINDOW_H
#define UI_LOGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QPushButton *testConnectStairsButton;
    QLineEdit *stairsPort;
    QLineEdit *stairsHost;
    QTableView *logs;
    QTableView *stairsUpdate;
    QLabel *label;
    QTableView *serverUpdate;
    QCheckBox *queue;
    QLineEdit *manual_rfid;
    QGroupBox *groupBox;
    QLabel *label_2;
    QLabel *label_3;
    QDateTimeEdit *manual_timestamp;
    QPushButton *sendStampButton;
    QLineEdit *manual_hwdid;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *LogWindow)
    {
        if (LogWindow->objectName().isEmpty())
            LogWindow->setObjectName(QStringLiteral("LogWindow"));
        LogWindow->resize(790, 650);
        centralWidget = new QWidget(LogWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        testConnectStairsButton = new QPushButton(centralWidget);
        testConnectStairsButton->setObjectName(QStringLiteral("testConnectStairsButton"));

        gridLayout->addWidget(testConnectStairsButton, 2, 0, 1, 1);

        stairsPort = new QLineEdit(centralWidget);
        stairsPort->setObjectName(QStringLiteral("stairsPort"));

        gridLayout->addWidget(stairsPort, 0, 1, 1, 1);

        stairsHost = new QLineEdit(centralWidget);
        stairsHost->setObjectName(QStringLiteral("stairsHost"));

        gridLayout->addWidget(stairsHost, 0, 0, 1, 1);

        logs = new QTableView(centralWidget);
        logs->setObjectName(QStringLiteral("logs"));

        gridLayout->addWidget(logs, 3, 0, 1, 1);

        stairsUpdate = new QTableView(centralWidget);
        stairsUpdate->setObjectName(QStringLiteral("stairsUpdate"));

        gridLayout->addWidget(stairsUpdate, 3, 1, 2, 2);

        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 8, 1, 1, 1);

        serverUpdate = new QTableView(centralWidget);
        serverUpdate->setObjectName(QStringLiteral("serverUpdate"));

        gridLayout->addWidget(serverUpdate, 4, 0, 1, 1);

        queue = new QCheckBox(centralWidget);
        queue->setObjectName(QStringLiteral("queue"));

        gridLayout->addWidget(queue, 6, 0, 1, 2);

        manual_rfid = new QLineEdit(centralWidget);
        manual_rfid->setObjectName(QStringLiteral("manual_rfid"));

        gridLayout->addWidget(manual_rfid, 9, 1, 1, 1);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 50, 101, 31));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(280, 70, 101, 41));
        manual_timestamp = new QDateTimeEdit(groupBox);
        manual_timestamp->setObjectName(QStringLiteral("manual_timestamp"));
        manual_timestamp->setGeometry(QRect(280, 581, 194, 22));

        gridLayout->addWidget(groupBox, 8, 0, 1, 1);

        sendStampButton = new QPushButton(centralWidget);
        sendStampButton->setObjectName(QStringLiteral("sendStampButton"));

        gridLayout->addWidget(sendStampButton, 2, 1, 1, 1);

        manual_hwdid = new QLineEdit(centralWidget);
        manual_hwdid->setObjectName(QStringLiteral("manual_hwdid"));
        manual_hwdid->setEnabled(true);

        gridLayout->addWidget(manual_hwdid, 9, 0, 1, 1);

        LogWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(LogWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        LogWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(LogWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        LogWindow->setStatusBar(statusBar);

        retranslateUi(LogWindow);

        QMetaObject::connectSlotsByName(LogWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LogWindow)
    {
        LogWindow->setWindowTitle(QApplication::translate("LogWindow", "Events", 0));
        testConnectStairsButton->setText(QApplication::translate("LogWindow", "Test Connection to Stairs", 0));
        stairsPort->setText(QApplication::translate("LogWindow", "8999", 0));
        stairsHost->setText(QApplication::translate("LogWindow", "127.0.0.1", 0));
        label->setText(QApplication::translate("LogWindow", "RFID", 0));
        queue->setText(QApplication::translate("LogWindow", "Queue on disconnected from stairs?", 0));
        groupBox->setTitle(QApplication::translate("LogWindow", "Manual Input", 0));
        label_2->setText(QApplication::translate("LogWindow", "Hwd ID", 0));
        label_3->setText(QApplication::translate("LogWindow", "<html><head/><body><p>Time Stamp</p></body></html>", 0));
        sendStampButton->setText(QApplication::translate("LogWindow", "Send\n"
"to Stairs", 0));
    } // retranslateUi

};

namespace Ui {
    class LogWindow: public Ui_LogWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGWINDOW_H
