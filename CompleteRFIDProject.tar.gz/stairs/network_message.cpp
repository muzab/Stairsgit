#include "network_message.h"


network_message::network_message(QObject *parent,
                                 const MessageType typ,               // message_get_all_station
                                 const QList<msg_station> &allStations) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream << (quint16)typ;
    /// TODO - use iterators
    for(int i; i < allStations.size(); ++i)
        stream << allStations[i].hwd_id << allStations[i].description;
}

network_message::network_message(QObject *parent,
                                 const MessageType typ,
                                 const QList<msg_rfid> &allRfids) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    // message_get_all_rfids
    stream << (quint16)typ;
    /// TODO - use iterators
    for(int i; i < allRfids.size(); ++i)
        stream << allRfids[i].rfid_tag << allRfids[i].firstname << allRfids[i].lastname;
}

network_message::network_message(QObject *parent,
                                 const MessageType typ,
                                 const QList<msg_race> &allTimes) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    // message_get_races_of
    stream << (quint16)typ;
    /// TODO - use iterators
    for(int i; i < allTimes.size(); ++i)
        stream << allTimes[i].from_station << allTimes[i].to_station
               << allTimes[i].distance << allTimes[i].kcal;
    /// TODO - floats have fixed size in the network but consistency with the integers where we have qunit16 or quinit32 etc?
}

void network_message::out(QDataStream &) {
//    outStream << stream;
}

