#ifndef M_TIMESTAMPS_H
#define M_TIMESTAMPS_H

#include <QObject>
#include <QDateTime>

class QSqlDatabase;

struct participantDta {
    QString stationUID;
    qreal   seconds;
};

class m_timestamps : public QObject
{
    Q_OBJECT

public:
    explicit m_timestamps(QObject *parent = 0);
    const QList<participantDta> &participantTimes(QString personUID) const; //For finished runs

signals:
    void runnerNewPosition(const QString stationUID,
                           const QString personUID,
                           const QString timestamp
                           );
    void bufferResponse(const QByteArray &data);

public slots:
    void stampRawEvent(const QString &station_hwdID,
                       const QString &person_rfID,
                       const QString &timestamp);
    void setStation1Data(const QString stationUID,
                      const QString personUID,
                      const QString &start_timestamp);
    void setStation2Data(const QString stationUID,
                        const QString personUID,
                        const QString &stop_timestamp);
    void setDB(const QSqlDatabase &db) {m_db = &db;}
    void getStation1Data();
    void getStation2Data();
    void getDatafromDB(const QString &rfid_tag, const QDateTime &timestamp);

private:
    const QSqlDatabase *m_db;
    QByteArray data;
};

#endif // M_TIMESTAMPS_H
