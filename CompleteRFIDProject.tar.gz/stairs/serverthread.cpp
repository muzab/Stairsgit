#include "serverthread.h"

#include <QTcpSocket>
#include <QBuffer>
#include <QDataStream>

ServerThread::ServerThread(int descriptor, QObject *parent)
    : QThread(parent), m_descriptor(descriptor)
{
}

void ServerThread::run() {
    QTcpSocket socket;
    if(!socket.setSocketDescriptor(m_descriptor)) {
        qDebug("Socket error!");
        return;
    }

    QBuffer buffer;
    ///

    QByteArray data;
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);
    stream << (quint32)buffer.data().size();
    data.append(buffer.data());

    socket.write(data);

    socket.disconnectFromHost();
    socket.waitForDisconnected();
}
