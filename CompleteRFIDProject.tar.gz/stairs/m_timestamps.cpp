#include "m_timestamps.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QSqlError>
#include <QDebug>
#include <QDataStream>
#include <QSqlRecord>

m_timestamps::m_timestamps(QObject *parent)
    : QObject( parent ), m_db(NULL)
{
}

void m_timestamps::setStation1Data(const QString stationUID,
                                const QString personRFID,
                                const QString &start_timestamp) {
    QSqlQuery qry;
    qry.prepare("insert into timestamp(station_id, participant_rfid, start_stamp)"
                " values(:station_id,:participant_id,DateTime(:stamp)"
              ")");
    qry.bindValue(":station_id", stationUID);
    qry.bindValue(":participant_id", personRFID);
    qry.bindValue(":stamp",start_timestamp);
    if(!qry.exec())
        qFatal("Unable to do Insert into the timestamp table");

/*    qry.prepare("DELETE FROM timestamp WHERE stamp IN (SELECT stamp FROM timestamp GROUP BY stamp HAVING COUNT(stamp) > 1)");
    if(!qry.exec())
        qFatal("Unable to remove duplicates from the timestamp table");
*/


    qry.prepare("UPDATE stairs SET start_stamp = :sstamp WHERE rfid_tag = :emprfid");
    qry.bindValue(":sstamp", start_timestamp);
    qry.bindValue(":emprfid", personRFID);
    if(!qry.exec())
        qWarning("Unable to do update start_timestamp into the stairs-table");
        qDebug() <<qry.lastInsertId();

    emit runnerNewPosition(stationUID, personRFID, start_timestamp);
}

void m_timestamps::setStation2Data(const QString stationUID,
                                const QString personRFID,
                                const QString &stop_timestamp) {
    QSqlQuery qry;
    qry.prepare("insert into Station2(station_id, participant_rfid, stop_stamp)"
                " values(:station_id,:participant_id,DateTime(:stamp)"
              ")");
    qry.bindValue(":station_id", stationUID);
    qry.bindValue(":participant_id", personRFID);
    qry.bindValue(":stamp",stop_timestamp);
    if(!qry.exec())
        qWarning("Unable to do Insert into the Station2 table");
        qDebug() <<qry.lastInsertId();
/*
    qry.prepare("UPDATE stairs SET stop_stamp = :sstamp WHERE rfid_tag = :emprfid");
    qry.bindValue(":sstamp", stop_timestamp);
    qry.bindValue(":emprfid", personRFID);
    if(!qry.exec())
            qWarning("Unable to do update start_timestamp into the stairs-table");
            qDebug() <<qry.lastInsertId();
*/
    emit runnerNewPosition(stationUID, personRFID, stop_timestamp);
}

void m_timestamps::stampRawEvent(const QString &station_hwdID,
                                 const QString &person_rfID,
                                 const QString &timestamp) {
    QSqlQuery qry;
    qry.prepare("select station_id from station where hwd_id = :hwd");
    qry.bindValue(":hwd", station_hwdID);
    if(!qry.exec())
        qFatal("Unable to do Select stations");

    if(!qry.next()) {
        qWarning("Hardware not registerd ");
        return;
    }
    QString station_id = qry.value(0).toString();

    qry.prepare("select participant_id from participant where rfid_tag = :rfid");
    qry.bindValue(":rfid", person_rfID);
    if(!qry.exec())
        qFatal("Unable to do Select participant");

    if(!qry.next()) {
        qWarning("RFID not registerd: ");
        return;
    }
    QString participant_id = qry.value(0).toString();

    setStation1Data(station_id, participant_id, timestamp);
}

void m_timestamps::getStation1Data()
{
    data.clear();
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);

    QSqlQuery qry;
   qry.prepare("select station_id, participant_rfid, start_stamp from timestamp");
    if(!qry.exec())
        qFatal("Unable to do Select on all timestamp data");
    while(qry.next()) {
        stream << qry.value(0).toString();
        stream << qry.value(1).toString();
        stream << qry.value(2).toString();
    }
/*
    qry.prepare("select emp_firstname, emp_lastname, start_stamp from stairs");
    if(!qry.exec())
        qFatal("Unable to do Select on all stairs data");
    while(qry.next()) {
        stream << qry.value(0).toString();
        stream << qry.value(1).toString();
        stream << qry.value(2).toString();
    }
*/
    emit bufferResponse(data);
}

void m_timestamps::getStation2Data()
{
    data.clear();
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);

    QSqlQuery qry;
    qry.prepare("select station_id, participant_rfid, stop_stamp from Station2");
    if(!qry.exec())
        qFatal("Unable to do Select on all station2 data");
    while(qry.next()) {
        stream << qry.value(0).toString();
        stream << qry.value(1).toString();
        stream << qry.value(2).toString();
    }
    emit bufferResponse(data);
}

/* 1) Search the 'RFID' in the 'participant' table
 * 2) Get the corresponding employee first and last name
 * 3) Call this function to send it to the LogWindow caller  */

void m_timestamps::getDatafromDB(const QString &rfid_tag, const QDateTime &timestamp)
{
    data.clear();
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);

    QSqlQuery qry;
    if( !qry.exec( "SELECT firstname, lastname FROM participants "
    "WHERE rfid_tag = :rfid " )){qDebug() << qry.lastError();}

    qry.bindValue(":rfid", rfid_tag);
    if(!qry.exec())
        qFatal("Unable to do select names");

    if(!qry.next()) {
        qWarning("RFID not registerd ");
        return;
    }
/*
    QSqlRecord rec = qry.record();
    int cols = rec.count();
    QString temp;
    for( int c=0; c<cols; c++ ){temp += rec.fieldName(c) + ((c<cols-1)?"\t":"");}
    qDebug() << temp;
    while( qry.next() )
    {
    temp = "";
    for( int c=0; c<cols; c++ ){temp += qry.value(c).toString() + ((c<cols-1)?"\t":"");}
    qDebug() << temp;
    }
*/
}

