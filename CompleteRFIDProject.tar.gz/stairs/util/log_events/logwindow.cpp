#include "logwindow.h"
#include "ui_logwindow.h"

#include <QBuffer>
#include <QMessageBox>
#include <QGuiApplication>

#include <QEvent>
#include <QObject>
#include <QDebug>
#include <QStandardItemModel>
#include <QDateTime>

#include <QNetworkAccessManager>
#include <QUrl>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>

#include "network_message.h"
#include "../../stairprotocol.h"


#ifndef QT_NO_SSL
 QUrl lora_url = QString::fromLocal8Bit("https://thethingsnetwork.org/api/v0/nodes/05060709/");
#else
 QUrl lora_url = QString::fromLocal8Bit("http://thethingsnetwork.org/api/v0/nodes/05060709/");
#endif

LogWindow::LogWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LogWindow), reply(Q_NULLPTR),
    stream(&data1, QIODevice::ReadWrite)
{
    ui->setupUi(this);
    ui->manual_timestamp->setDateTime(QDateTime::currentDateTimeUtc());

    model = new QStandardItemModel(1,2,this);
    headers = QStringList() << "Employee-RFID" << "Start-Time" << "Stop-Time" <<"Time-Lapsed";
    model->setHorizontalHeaderLabels(headers);
    model->setColumnCount(headers.size());


    /* Http-Network request to TTN (The Things Network) */
    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)),
            this, SLOT(replyFinished(QNetworkReply*)));

    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(connectStation1()));
    connect(timer, SIGNAL(timeout()), this, SLOT(connectStation2()));
    timer->start(5000);
    // Kick-off the first refresh immediately.
    connectStation1();

    connect(&socket,
            SIGNAL(error(QAbstractSocket::SocketError)),
            this,
            SLOT(tcpError(QAbstractSocket::SocketError)));

    connect(&socket,
            SIGNAL(readyRead()),
            this,
            SLOT(tcpReady()));

    stream.setVersion(QDataStream::Qt_4_0);
}

LogWindow::~LogWindow()
{
    delete ui;
}

/* Get Station-1 Data */
void LogWindow::getStation1DataFromMessage(QList<msg_station1data> &station1data, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_station1data stationData;
        stream >> stationData.stationID;
        stream >> stationData.rf_id;
        stream >> stationData.start_timestamp;
        station1data.append(stationData);
    }
}

/* Add Station-1 data to TableView */
QStandardItemModel * LogWindow::fillStation1DataView(QList<msg_station1data> &station1data)
{
    QStandardItemModel *model = new QStandardItemModel(station1data.size(), 2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Station-Id")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("RFID")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("Start-Time")));
    int n = 0;
    foreach(msg_station1data d, station1data) {
        QStandardItem *item = new QStandardItem(QString(d.stationID));
        model->setItem(n,0,item);
        item = new QStandardItem(QString(d.rf_id));
        model->setItem(n,1,item);
//        item = new QStandardItem((d.start_timestamp).toString("yyyy-MM-dd HH:mm:ss"));
        item = new QStandardItem(QString(d.start_timestamp));
        model->setItem(n,2,item);
        ++n;
    }

    return model;
}

/* Get Station-2 Data */
void LogWindow::getStation2DataFromMessage(QList<msg_station2data> &station2data, QDataStream &stream)
{
    while(!stream.atEnd())
    {
        msg_station2data stationData;
        stream >> stationData.stationID;
        stream >> stationData.rf_id;
        stream >> stationData.stop_timestamp;
        station2data.append(stationData);
    }

}

/* Add Station-2 data to TableView */
QStandardItemModel * LogWindow::fillStation2DataView(QList<msg_station2data> &station2data)
{
    QStandardItemModel *model = new QStandardItemModel(station2data.size(), 2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Station-Id")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("RFID")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("Stop-Time")));
    int n = 0;

    foreach(msg_station2data d, station2data) {
        QStandardItem *item = new QStandardItem(QString(d.stationID));
        model->setItem(n,0,item);
        item = new QStandardItem(QString(d.rf_id));
        model->setItem(n,1,item);
        item = new QStandardItem(QString(d.stop_timestamp));
        model->setItem(n,2,item);
        ++n;
    }

    return model;
}

void LogWindow::tcpReady()
{
    if(!data1.isEmpty()) {
        stream << (quint32)data1.size();
        socket.write(data1);
        data1.clear();
    }

    QDataStream stream(&socket);
    stream.setVersion(QDataStream::Qt_4_0);
    if(dataSize == 0) {
        if(socket.bytesAvailable() < sizeof(quint32))
            return;
        stream >> dataSize;
    }
    if(dataSize > socket.bytesAvailable())
        return;
    quint16 mt;
    stream >> mt;
    MessageType typ = static_cast<MessageType>(mt);
    switch(typ) {

    case SUBMIT_STATION1_DATA:
        {
        QList<msg_station1data> station1data;
        getStation1DataFromMessage(station1data, stream);
        QStandardItemModel *model = fillStation1DataView(station1data);
        ui->serverUpdate->setModel(model);
        }
        break;

    case SUBMIT_STATION2_DATA:
        {
        QList<msg_station2data> station2data;
        getStation2DataFromMessage(station2data, stream);
        QStandardItemModel *model = fillStation2DataView(station2data);
        ui->stairsUpdate->setModel(model);
        }
        break;

    default:
        QMessageBox::warning(this,
                             tr("Error in Stairs"),
                             tr("Message type: %1 dataSize %2")
                                .arg(QString::number(typ),dataSize));
        break;
    }
    ui->testConnectStairsButton->setEnabled(true);
    ui->sendStampButton->setEnabled(true);    
}

void LogWindow::tcpError(QAbstractSocket::SocketError error)
{
    if(error!=QAbstractSocket::RemoteHostClosedError)
        QMessageBox::warning(this, tr("Error"), tr("TCP error: %1").arg(socket.errorString()));
    ui->testConnectStairsButton->setEnabled(true);
    ui->sendStampButton->setEnabled(true);
}

void LogWindow::on_testConnectStairsButton_clicked()
{
    network_message request(this, REQUEST_STATION1_DATA);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
    ui->testConnectStairsButton->setEnabled(true);
}

void LogWindow::on_sendStampButton_clicked()
{
    network_message request(this, REQUEST_STATION2_DATA);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
    ui->sendStampButton->setEnabled(true);

/*    network_message add_stamp(this,
                              ui->manual_hwdid->text(),
                              ui->manual_rfid->text(),
                              ui->manual_timestamp->text());
    add_stamp.out(msg);
    socket.abort();
    socket.connectToHost(ui->stairsHost->text(),ui->stairsPort->text().toInt());
    socket.write(msg);
    socket.close();
    ui->sendStampButton->setEnabled(true);
*/
}

void LogWindow::slotReadyRead_S1()
{
//    while(reply->bytesAvailable())
//    {
        byteResponse = (QByteArray)reply->readAll();
//      qDebug() <<"Buffer ="<<byteResponse;
        jsonResponse = QJsonDocument::fromJson(byteResponse);
        jsonObject = jsonResponse.object();

        if(jsonResponse.isObject())
        {
            qDebug() <<"document is an object";
            data.append(jsonObject["data"].toString());
            time.append(jsonObject["time"].toString());

            //Check for "stop_time" for the same rfid and store the
            //time-stamp in the DB.
        }

        else if(jsonResponse.isArray())
        {
            jsonArray = jsonResponse.array();
            qDebug() <<"Document is an Array";

            foreach(const QJsonValue &value, jsonArray)
            {
                QJsonObject obj = value.toObject();
                data.append(obj["data"].toString());
                time.append(obj["time"].toString());
                node_ID.append(obj["node_eui"].toString());
            }

            QByteArray ba = QByteArray::fromBase64(data.toLatin1());
            QString rf_ID(ba.toHex());
            QDateTime timestamp = QDateTime::fromString(time,Qt::ISODate);

            QStandardItem *firstCol = new QStandardItem(rf_ID);
            QStandardItem *secondCol = new QStandardItem(time);

            model->setItem(0,0,firstCol);
            model->setItem(0,1,secondCol);
            ui->logs->setModel(model);

            adjustTableSize();

            qDebug() <<timestamp;
            qDebug() <<time;
            qDebug() <<rf_ID;
            qDebug() <<node_ID;
         
//            sendToStairs(node_ID, rf_ID, (QDateTime::fromString(time,"yyyy:MM:dd HH:mm:ss")));
//            sendToStairs(node_ID, rf_ID, timestamp.toString("HH:mm:ss"));
            sendToStairs(node_ID, rf_ID, time);
        }

        else{ }
//    }

        data.clear();
        time.clear();
        node_ID.clear();
}

void LogWindow::slotReadyRead_S2()
{

}

void LogWindow::replyFinished(QNetworkReply* response)
{

    const QVariant redirectionTarget = response->attribute(QNetworkRequest::RedirectionTargetAttribute);

    if (!redirectionTarget.isNull())
    {
        const QUrl newUrl = lora_url.resolved(redirectionTarget.toUrl());
        QNetworkRequest request(newUrl);
        manager->get(request);
        return;
    }
    else
    {
        qDebug() <<"replyFinished read ="<< response->readAll();
    }

    response->deleteLater();
}

void LogWindow::slotError(QNetworkReply::NetworkError){}

void LogWindow::connectStation1()
{
    /*  Use "?offset=xx" to reach the desired array positions in Json and "?limit=0" for the latest entry*/
    lora_url = QString::fromLocal8Bit("http://thethingsnetwork.org/api/v0/nodes/05060708/?limit=1");
    QNetworkRequest lora_request(lora_url);
    reply = manager->get(lora_request);

    connect(reply, SIGNAL(readyRead()), this, SLOT(slotReadyRead_S1()));
}

void LogWindow::connectStation2()
{
    /*  Use "?offset=xx" to reach the desired array positions in Json and "?limit=0" for the latest entry*/
    lora_url = QString::fromLocal8Bit("http://thethingsnetwork.org/api/v0/nodes/05060709/?limit=1");
    QNetworkRequest lora_request(lora_url);
    reply = manager->get(lora_request);

    connect(reply, SIGNAL(readyRead()), this, SLOT(slotReadyRead_S1()));

}

void LogWindow::compareStation1()
{
    /* Compare previous data from Station-2 and send it to Stairs-DB */

}

void LogWindow::adjustTableSize()
{
    ui->logs->resizeColumnsToContents();
    ui->logs->resizeRowToContents(0);
    ui->logs->resizeRowToContents(1);
    QRect rect = ui->logs->geometry();
    ui->logs->setGeometry(rect);
}

void LogWindow::sendToStairs(QString node_ID, QString rf_ID, QString time_Stamp)
{
    network_message add_stamp(this, node_ID, rf_ID, time_Stamp);
    add_stamp.out(msg);
    socket.abort();
    socket.connectToHost(ui->stairsHost->text(),ui->stairsPort->text().toInt());
    socket.write(msg);
    socket.close();
    ui->sendStampButton->setEnabled(true);
}

#ifndef QT_NO_SSL
void LogWindow::sslErrors(QNetworkReply*,const QList<QSslError> &errors)
{
    QString errorString;
    foreach (const QSslError &error, errors) {
        if (!errorString.isEmpty())
            errorString += '\n';
        errorString += error.errorString();
    }

    if (QMessageBox::warning(this, tr("SSL Errors"),
                             tr("One or more SSL errors has occurred:\n%1").arg(errorString),
                             QMessageBox::Ignore | QMessageBox::Abort) == QMessageBox::Ignore) {
        reply->ignoreSslErrors();
    }
}
#endif
