#ifndef NETWORK_MESSAGE_H
#define NETWORK_MESSAGE_H

#include <QString>
#include <QDateTime>
#include <QDataStream>

#include "../../stairprotocol.h"

// only this message is sent:
//    PING =          0x00,
//    ADD_STAMP =     0x04,
//
// but no message is received


class network_message: public QObject
{
    Q_OBJECT

public:
    // the message type is
    explicit network_message(QObject *parent);                   // PING    
    explicit network_message(QObject *parent,
                             const QString &hwd_id,
                             const QString &rfid_tag,
                             const QString &stamp);            // message_add_checkpoint
    explicit network_message(QObject *parent,
                             const MessageType requestType);     // REQUEST_STATIONS & REQUEST_RFIDS
    void out(QByteArray &outBuffer);

signals:
    // no received messages

public slots:

private:
    QByteArray data;
    QDataStream stream;
};


#endif // NETWORK_MESSAGE_H
