#ifndef LOGWINDOW_H
#define LOGWINDOW_H

#include <QMainWindow>
#include <QAbstractSocket>
#include <QTcpSocket>

#include <QNetworkAccessManager>
#include <QUrl>
#include <QNetworkRequest>
#include <QNetworkReply>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include <QStandardItemModel>
#include "../../stairprotocol.h"

namespace Ui {
class LogWindow;
}

class LogWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit LogWindow(QWidget *parent = 0);
    void sendToStairs(QString, QString, QString);
    void compareStation1();
    void compareStation2();

    void getStation1DataFromMessage(QList<msg_station1data> &station1data, QDataStream &stream);
    void getStation2DataFromMessage(QList<msg_station2data> &station2data, QDataStream &stream);

    QStandardItemModel * fillStation1DataView(QList<msg_station1data> &station1data);
    QStandardItemModel * fillStation2DataView(QList<msg_station2data> &station2data);

    ~LogWindow();


public slots:


private slots:
    void tcpReady();
    void tcpError(QAbstractSocket::SocketError error);

//    void bytesWritten(qint64 bytes);
//    void disconnected();
//    void connected();


    void replyFinished(QNetworkReply*);
    void slotReadyRead_S1();
    void slotReadyRead_S2();
    void slotError(QNetworkReply::NetworkError);

    void on_sendStampButton_clicked();
    void on_testConnectStairsButton_clicked();
    void adjustTableSize();

    void connectStation1();
    void connectStation2();

#ifndef QT_NO_SSL
    void sslErrors(QNetworkReply*,const QList<QSslError> &errors);
#endif



private:
    Ui::LogWindow *ui;

    QByteArray msg;
    QByteArray data1;
    QTcpSocket socket;
    QDataStream stream;
    int dataSize;

    /* To connect with LoRa Network*/

    QUrl lora_url;
    QNetworkAccessManager *manager;
    QNetworkReply *reply;
    QString data;
    QString time;
    QString node_ID;
    QStringList stop_Time;
    QStringList time_lapsed;
    QByteArray byteResponse;
    QString byteString;



    /* To Read Json file */
    QJsonDocument jsonResponse;
    QJsonObject jsonObject;
    QJsonArray jsonArray;

    /* TableView */
    QStandardItemModel *model;
    QStringList headers;

};

#endif // LOGWINDOW_H
