#include "network_message.h"

network_message::network_message(QObject *parent) : QObject(parent), stream(&data, QIODevice::WriteOnly)
{
    stream.setVersion(QDataStream::Qt_4_0);
    stream << (quint16)PING;
}

network_message::network_message(QObject *parent,
                         const QString &hwd_id,
                         const QString &rfid_tag,
                         const QString &stamp) : QObject(parent), stream(&data, QIODevice::WriteOnly)
{
    stream.setVersion(QDataStream::Qt_4_0);
//    stream << (quint16)ADD_STAMP << hwd_id << rfid_tag << stamp;
    stream << (quint16)SUBMIT_STATION2_DATA << hwd_id << rfid_tag << stamp;
}

network_message::network_message(QObject *parent,
                                 const MessageType requestType) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    switch(requestType)
    {
        case REQUEST_STATIONS:

        case REQUEST_STATION1_DATA:
                stream.setVersion(QDataStream::Qt_4_0);
                stream << (quint16)requestType;
        break;

        case REQUEST_STATION2_DATA:
                stream.setVersion(QDataStream::Qt_4_0);
                stream << (quint16)requestType;
        break;

    default:
        qFatal("Wrong message type");
    }
}

void network_message::out(QByteArray &outBuffer) {
    outBuffer.clear(); // start with a clean slate
    // Send the size for all the stream
    QByteArray preData;
    QDataStream preStream(&preData, QIODevice::WriteOnly);
    preStream.setVersion(QDataStream::Qt_4_0);
    preStream << (quint32) data.length();
    outBuffer.append(preData);
    outBuffer.append(data);
}
