#include "logwindow.h"
#include <QApplication>
#include <QtWidgets>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LogWindow w;

//    QVBoxLayout *mainLayout = new QVBoxLayout();
    w.show();


    return a.exec();
}
