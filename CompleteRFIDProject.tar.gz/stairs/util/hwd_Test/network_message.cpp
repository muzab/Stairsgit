#include "network_message.h"

network_message::network_message(QObject *parent,
                                 const msg_station &station) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream.setVersion(QDataStream::Qt_4_0);
    // message_add_station
    stream << (quint16)ADD_STATION << station.hwd_id << station.description;
}

network_message::network_message(QObject *parent,
                                 const msg_rfid &rfid) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream.setVersion(QDataStream::Qt_4_0);
    // message_add_rfid
    stream << (quint16)ADD_RFID << rfid.rfid_tag << rfid.firstname << rfid.lastname;
}

network_message::network_message(QObject *parent,
                                 const MessageType requestType) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    switch(requestType) {
    case REQUEST_STATIONS:
    case REQUEST_RFIDS:
        stream.setVersion(QDataStream::Qt_4_0);
        stream << (quint16)requestType;
        break;
    default:
        qFatal("Wrong message type");
    }
}

void network_message::out(QByteArray &outBuffer) {
    outBuffer.clear(); // start with a clean slate
    // Send the size for all the stream
    QByteArray preData;
    QDataStream preStream(&preData, QIODevice::WriteOnly);
    preStream.setVersion(QDataStream::Qt_4_0);
    preStream << (quint32) data.length();
    outBuffer.append(preData);
    outBuffer.append(data);
}
