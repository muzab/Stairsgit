#include "hwdwindow.h"
#include "ui_hwdwindow.h"

#include "network_message.h"

#include <QBuffer>
#include <QMessageBox>
#include <QStandardItemModel>

HWdWindow::HWdWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HWdWindow),
    stream(&data, QIODevice::WriteOnly)
{
    ui->setupUi(this);

    connect(&socket,
            SIGNAL(error(QAbstractSocket::SocketError)),
            this,
            SLOT(tcpError(QAbstractSocket::SocketError)));
    connect(&socket,
            SIGNAL(readyRead()),
            this,
            SLOT(tcpReady()));
    stream.setVersion(QDataStream::Qt_4_0);
}

HWdWindow::~HWdWindow()
{
    delete ui;
}

void HWdWindow::getStationsFromMessage(QList<msg_station> &stations, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_station station;
        stream >> station.hwd_id;
        stream >> station.description;
        stations.append(station);
    }
}

void HWdWindow::getRfidFromMessage(QList<msg_rfid> &rfids, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_rfid rfid;
        stream >> rfid.rfid_tag;
        stream >> rfid.firstname;
        stream >> rfid.lastname;
        rfids.append(rfid);
    }
}

QStandardItemModel * HWdWindow::fillStationsView(QList<msg_station> &stations)
{
    QStandardItemModel *model = new QStandardItemModel(stations.size(), 2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Id")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Description")));
    int n = 0;
    foreach(msg_station s, stations) {
        QStandardItem *item = new QStandardItem(QString(s.hwd_id));
        model->setItem(n,0,item);
        item = new QStandardItem(QString(s.description));
        model->setItem(n,1,item);
        ++n;
    }

    return model;
}

QStandardItemModel * HWdWindow::fillRfidsView(QList<msg_rfid> &rfids)
{
    QStandardItemModel *model = new QStandardItemModel(rfids.size(), 2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Id")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("First Name")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("Last Name")));
    int n = 0;
    foreach(msg_rfid r, rfids) {
        QStandardItem *item = new QStandardItem(QString(r.rfid_tag));
        model->setItem(n,0,item);
        item = new QStandardItem(QString(r.firstname));
        model->setItem(n,1,item);
        item = new QStandardItem(QString(r.lastname));
        model->setItem(n,2,item);
        ++n;
    }

    return model;
}

void HWdWindow::tcpReady() {
    if(!data.isEmpty()) {
        stream << (quint32)data.size();
        socket.write(data);
        data.clear();
    }

    QDataStream stream(&socket);
    stream.setVersion(QDataStream::Qt_4_0);
    if(dataSize == 0) {
        if(socket.bytesAvailable() < sizeof(quint32))
            return;
        stream >> dataSize;
    }
    if(dataSize > socket.bytesAvailable())
        return;
    quint16 mt;
    stream >> mt;
    MessageType typ = static_cast<MessageType>(mt);
    switch(typ) {
    case ALL_STATIONS:
        {
        QList<msg_station> stations;
        getStationsFromMessage(stations, stream);
        QStandardItemModel *model = fillStationsView(stations);
        ui->stations->setModel(model);
        }
        break;
    case ALL_RFIDS:
        {
        QList<msg_rfid> rfids;
        getRfidFromMessage(rfids, stream);
        QStandardItemModel *model = fillRfidsView(rfids);
        ui->rfids->setModel(model);
        }
        break;
    default:
        QMessageBox::warning(this,
                             tr("Error in Stairs"),
                             tr("Message type: %1 dataSize %2")
                                .arg(QString::number(typ),dataSize));
        break;
    }
    ui->sendStationButton->setEnabled(true);
    ui->sendRfidButton->setEnabled(true);
}

void HWdWindow::tcpError(QAbstractSocket::SocketError error) {
    if(error == QAbstractSocket::RemoteHostClosedError)
        return;

    QMessageBox::warning(this,
                         tr("Error trying to reach Stairs"),
                         tr("TCP error: %1").arg(socket.errorString()));
    ui->sendStationButton->setEnabled(true);
    ui->sendRfidButton->setEnabled(true);
}

void HWdWindow::sendAStation(msg_station &station)
{
    network_message add_station_message(this, station);
    add_station_message.out(msg);
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
    socket.close();
}

void HWdWindow::on_sendStationButton_clicked()
{
    msg_station station;
    station.hwd_id = ui->hwd_id->text();
    station.description = ui->description->text();
    sendAStation(station);
    ui->sendStationButton->setEnabled(false);
}

void HWdWindow::sendAnRfid(msg_rfid &rfid)
{
    network_message add_rfid(this, rfid);
    add_rfid.out(msg);
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
    socket.close();

}

void HWdWindow::on_sendRfidButton_clicked()
{
    msg_rfid rfid;

    rfid.rfid_tag = ui->rfid_tag->text();
    rfid.firstname = ui->firstname->text();
    rfid.lastname = ui->lastname->text();
    sendAnRfid(rfid);
    ui->sendRfidButton->setEnabled(true);
}

void HWdWindow::on_updateStations_clicked()
{
    network_message request(this, REQUEST_STATIONS);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
}

void HWdWindow::on_updateRfids_clicked()
{
    network_message request(this, REQUEST_RFIDS);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);

}
