#ifndef HWDWINDOW_H
#define HWDWINDOW_H

#include <QMainWindow>
#include <QAbstractSocket>
#include <QTcpSocket>

class msg_rfid;
class msg_station;
class QStandardItemModel;

namespace Ui {
class HWdWindow;
}

class HWdWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit HWdWindow(QWidget *parent = 0);
    ~HWdWindow();

    void getStationsFromMessage(QList<msg_station> &stations, QDataStream &stream);
    void getRfidFromMessage(QList<msg_rfid> &rfids, QDataStream &stream);
    
    QStandardItemModel * fillStationsView(QList<msg_station> &stations);
    QStandardItemModel * fillRfidsView(QList<msg_rfid> &rfids);
    
public slots:
    void tcpReady();
    void tcpError(QAbstractSocket::SocketError error);

protected:
    void sendAnRfid(msg_rfid &rfid);
    void sendAStation(msg_station &station);

private slots:
    void on_sendStationButton_clicked();
    void on_sendRfidButton_clicked();

    void on_updateStations_clicked();
    void on_updateRfids_clicked();

private:
    Ui::HWdWindow *ui;

    QByteArray msg;
    QTcpSocket socket;
    int dataSize;
    QByteArray data;
    QDataStream stream;
};

#endif // HWDWINDOW_H
