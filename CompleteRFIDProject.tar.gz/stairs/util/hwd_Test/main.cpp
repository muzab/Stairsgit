#include "hwdwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    HWdWindow w;
    w.show();

    return a.exec();
}
