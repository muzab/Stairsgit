#ifndef NETWORK_MESSAGE_H
#define NETWORK_MESSAGE_H

#include <QString>
#include <QDateTime>
#include <QDataStream>

#include "../../stairprotocol.h"

// these messages are sent:
//    PING =          0x00,
//    ADD_STATION =   0x01,
//    ADD_RFID =      0x02,
//    REQUEST_STATIONS =  0x20,
//    REQUEST_RFIDS =     0x21,
// these messages are received


class network_message : public QObject
{
    Q_OBJECT

public:
    // the message types are
    explicit network_message(QObject *parent);                   // PING
    explicit network_message(QObject *parent,
                             const msg_station &station);        // message_add_station
    explicit network_message(QObject *parent,
                             const msg_rfid &rfid);              // message_add_rfid
    explicit network_message(QObject *parent,
                             const MessageType requestType);     // REQUEST_STATIONS & REQUEST_RFIDS
    void out(QByteArray &outBuffer);

signals:

public slots:

private:
    QByteArray data;
    QDataStream stream;
};

#endif // NETWORK_MESSAGE_H
