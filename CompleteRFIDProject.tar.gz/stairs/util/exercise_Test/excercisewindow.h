#ifndef EXCERCISEWINDOW_H
#define EXCERCISEWINDOW_H

#include <QMainWindow>
#include <QAbstractSocket>
#include <QTcpSocket>
#include <QStandardItemModel>

class msg_rfid;
class msg_station;
//class QStandardItemModel;

class msg_rfid;
class msg_station;
class msg_race;
class QStandardItemModel;

namespace Ui {
class ExcerciseWindow;
}

class ExcerciseWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit ExcerciseWindow(QWidget *parent = 0);
    ~ExcerciseWindow();

    void getStationsFromMessage(QList<msg_station> &stations, QDataStream &stream);
    void getRfidFromMessage(QList<msg_rfid> &rfids, QDataStream &stream);
    void getRaceFromMessage(QList<msg_race> &rfids, QDataStream &stream);

    QStandardItemModel * fillStationsView(QList<msg_station> &stations);
    QStandardItemModel * fillRfidsView(QList<msg_rfid> &rfids);
    QStandardItemModel * fillRacesView(QList<msg_race> &rfids);

private slots:
    void on_setRaceButton_clicked();
    void tcpReady();
    void tcpError(QAbstractSocket::SocketError error);
    void updateStations();
    void updateRfids();
    void handleParticipantChanged(int);



protected:
    void sendAnRfid(msg_rfid &rfid);
    void sendAStation(msg_station &station);

private:
    Ui::ExcerciseWindow *ui;

    QByteArray msg;
    QTcpSocket socket;
    int dataSize;    
    QByteArray data;
    QDataStream stream;

    QList<msg_rfid> rfids;
};

#endif // EXCERCISEWINDOW_H
