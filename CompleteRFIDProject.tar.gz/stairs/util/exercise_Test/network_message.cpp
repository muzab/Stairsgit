#include "network_message.h"

network_message::network_message(QObject *parent,
                                 const QString &from_station,
                                 const QString &to_station,
                                 const float distanceMeters,
                                 const float kcal) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream.setVersion(QDataStream::Qt_4_0);
    // message_add_distance
    stream << (quint16)ADD_DISTANCE << from_station << to_station << distanceMeters << kcal;
    /// TODO - floats have fixed size in the network but consistency with the integers where we have qunit16 or quinit32 etc?
}

network_message::network_message(QObject *parent,
                                 const MessageType requestType) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream.setVersion(QDataStream::Qt_4_0);
    switch(requestType) {
    case DEL_ALL_DISTANCES: // message_delete_all_distance
        stream << (quint16)requestType;
        break;
    case REQUEST_STATIONS:
    case REQUEST_RFIDS:
        stream.setVersion(QDataStream::Qt_4_0);
        stream << (quint16)requestType;
        break;
    default:
        qFatal("Wrong message type");
    }
}

network_message::network_message(QObject *parent,
                                 const int parent_id) : QObject(parent), stream(&data, QIODevice::WriteOnly) {
    stream.setVersion(QDataStream::Qt_4_0);
    // REQUEST_PERSONAL_RACES
    stream << (quint16)REQUEST_PERSONAL_RACES << parent_id;
}

void network_message::out(QByteArray &outBuffer) {
    outBuffer.clear(); // start with a clean slate
    // Send the size for all the stream
    QByteArray preData;
    QDataStream preStream(&preData, QIODevice::WriteOnly);
    preStream.setVersion(QDataStream::Qt_4_0);
    preStream << (quint32) data.length();
    outBuffer.append(preData);
    outBuffer.append(data);
}
