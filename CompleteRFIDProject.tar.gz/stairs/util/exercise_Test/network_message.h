#ifndef NETWORK_MESSAGE_H
#define NETWORK_MESSAGE_H

#include <QString>
#include <QDateTime>
#include <QDataStream>

#include "../../stairprotocol.h"

// these messages are sent:
//    PING =          0x00,
//    ADD_DISTANCE =  0x03,
//    DEL_ALL_DISTANCES =  0x10,
// these messages are received

class network_message : public QObject
{
    Q_OBJECT

public:
    // the message types are
    explicit network_message(QObject *parent);                   // PING
    explicit network_message(QObject *parent,
                             const QString &from_station,
                             const QString &to_station,
                             const float distanceMeters,
                             const float kcal);                  // message_add_distance
    explicit network_message(QObject *parent,
                             const MessageType typ);             // message_delete_all_distance
    explicit network_message(QObject *parent,
                             const int parent_id);               // REQUEST_PERSONAL_RACES
    void out(QByteArray &outBuffer);

signals:

public slots:

private:
    QByteArray data;
    QDataStream stream;
};

#endif // NETWORK_MESSAGE_H
