#include "excercisewindow.h"
#include "ui_excercisewindow.h"

#include <QBuffer>
#include <QMessageBox>
#include <QStandardItemModel>

#include "network_message.h"

ExcerciseWindow::ExcerciseWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ExcerciseWindow)
{
    ui->setupUi(this);
    connect(&socket,
            SIGNAL(error(QAbstractSocket::SocketError)),
            this,
            SLOT(tcpError(QAbstractSocket::SocketError)));
    connect(&socket,
            SIGNAL(readyRead()),
            this,
            SLOT(tcpReady()));
    connect(ui->participant,
            SIGNAL(currentIndexChanged(int)),
            this,
            SLOT(handleParticipantChanged(int))
            );
    updateStations();
}

ExcerciseWindow::~ExcerciseWindow()
{
    delete ui;
}

void ExcerciseWindow::tcpReady() {
    if(!data.isEmpty()) {
        stream << (quint32)data.size();
        socket.write(data);
        data.clear();
    }

    QDataStream stream(&socket);
    stream.setVersion(QDataStream::Qt_4_0);
    if(dataSize == 0) {
        if(socket.bytesAvailable() < sizeof(quint32))
            return;
        stream >> dataSize;
    }
    if(dataSize > socket.bytesAvailable())
        return;
    quint16 mt;
    stream >> mt;
    MessageType typ = static_cast<MessageType>(mt);
    switch(typ) {
    case ALL_STATIONS:
        {
        QList<msg_station> stations;
        getStationsFromMessage(stations, stream);
        QStandardItemModel *model = fillStationsView(stations);
        ui->from_station->setModel(model);
        ui->to_station->setModel(model);
        }
        updateRfids();
        break;
    case ALL_RFIDS:
        {
        getRfidFromMessage(rfids, stream);
        QStandardItemModel *model = fillRfidsView(rfids);
        ui->participant->setModel(model);
        }
        break;
    case ALL_PERSONAL_RACES:
        {
        QList<msg_race> races;
        getRaceFromMessage(races, stream);
        QStandardItemModel *model = fillRacesView(races);
        ui->sel_statistics->setModel(model);
        }
        break;
    default:
        QMessageBox::warning(this,
                             tr("Error in Stairs"),
                             tr("Message type: %1 dataSize %2")
                                .arg(QString::number(typ),dataSize));
        break;
    }
//    ui->testConnectStairsButton->setEnabled(true);
//    ui->sendStampButton->setEnabled(true);
//    ui->setRaceButton->setEnabled(true);
}

void ExcerciseWindow::tcpError(QAbstractSocket::SocketError error) {
    if(error!=QAbstractSocket::RemoteHostClosedError)
        QMessageBox::warning(this, tr("Error"), tr("TCP error: %1").arg(socket.errorString()));
//    ui->testConnectStairsButton->setEnabled(true);
//    ui->sendStampButton->setEnabled(true);
}

void ExcerciseWindow::on_setRaceButton_clicked()
{
    network_message ping_message(this,
                                 "",//ui->from_station->,
                                 "",//ui->to_station,
                                 ui->distanceMeters->text().toFloat(),
                                 ui->kcal->text().toFloat());
    ping_message.out(msg);
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
    socket.close();
    ui->setRaceButton->setEnabled(true);
}

void ExcerciseWindow::updateStations()
{
    network_message request(this, REQUEST_STATIONS);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
}

void ExcerciseWindow::updateRfids()
{
    network_message request(this, REQUEST_RFIDS);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
}

void ExcerciseWindow::handleParticipantChanged(int n)
{
    msg_rfid rfid = rfids[n];
    network_message request(this, rfid.rfid_tag.toInt()); // REQUEST_PERSONAL_RACES
    ui->sel_firstname->setText(rfid.firstname);
    ui->sel_lastname->setText(rfid.lastname);
    request.out(msg);
    dataSize = 0;
    socket.abort();
    socket.connectToHost(
                "127.0.0.1",
                8999);
    socket.write(msg);
}

void ExcerciseWindow::getStationsFromMessage(QList<msg_station> &stations, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_station station;
        stream >> station.hwd_id;
        stream >> station.description;
        stations.append(station);
    }
}

void ExcerciseWindow::getRfidFromMessage(QList<msg_rfid> &rfids, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_rfid rfid;
        stream >> rfid.rfid_tag;
        stream >> rfid.firstname;
        stream >> rfid.lastname;
        rfids.append(rfid);
    }
}

void ExcerciseWindow::getRaceFromMessage(QList<msg_race> &races, QDataStream &stream)
{
    while(!stream.atEnd()) {
        msg_race race;
        stream >> race.from_station;
        stream >> race.to_station;
        stream >> race.distance;
        stream >> race.kcal;
        stream >> race.minutes;
        races.append(race);
    }
}

QStandardItemModel *ExcerciseWindow::fillStationsView(QList<msg_station> &stations)
{
    QStandardItemModel *model = new QStandardItemModel(stations.size(), 0,this);
//    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Id")));
    int n = 0;
    foreach(msg_station s, stations) {
        QStandardItem *item = new QStandardItem(QString(s.hwd_id));
        model->setItem(n,0,item);
        item = new QStandardItem(QString(s.description));
        model->setItem(n,1,item);
        ++n;
    }

    return model;
}

QStandardItemModel *ExcerciseWindow::fillRfidsView(QList<msg_rfid> &rfids)
{
    QStandardItemModel *model = new QStandardItemModel(rfids.size(), 0,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Id")));
    int n = 0;
    foreach(msg_rfid r, rfids) {
        QStandardItem *item = new QStandardItem(QString(r.rfid_tag));
        model->setItem(n,0,item);
        ++n;
    }

    return model;
}


QStandardItemModel * ExcerciseWindow::fillRacesView(QList<msg_race> &races)
{
    QStandardItemModel *model = new QStandardItemModel(races.size(), 2,this);
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("station id")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("stamp")));
    int n = 0;
    foreach(msg_race r, races) {
        QStandardItem *item = new QStandardItem(QString(r.from_station));
        model->setItem(n,0,item);
        item = new QStandardItem(r.minutes);
        model->setItem(n,1,item);
        ++n;
    }

    return model;
}
