#ifndef SERVERTHREAD_H
#define SERVERTHREAD_H

#include <QThread>
#include <QAbstractSocket>


// Will be used if we make it listening to sockets multithreaded
// depends on resources of the device we use to implement Stairs


class ServerThread : public QThread
{
public:
    explicit ServerThread(int descriptor, QObject *parent);
    void run();

signals:
    // no received messages

public slots:
    void tcpError(QAbstractSocket::SocketError error);

private:
    int m_descriptor;
};

#endif // SERVERTHREAD_H
