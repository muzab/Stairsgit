/********************************************************************************
** Form generated from reading UI file 'logwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGWINDOW_H
#define UI_LOGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogWindow
{
public:
    QWidget *centralWidget;
    QPushButton *testConnectStairsButton;
    QLineEdit *stairsHost;
    QLineEdit *stairsPort;
    QTableView *logs;
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QDateTimeEdit *manual_timestamp;
    QLineEdit *manual_hwdid;
    QLineEdit *manual_rfid;
    QPushButton *sendStampButton;
    QCheckBox *queue;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *LogWindow)
    {
        if (LogWindow->objectName().isEmpty())
            LogWindow->setObjectName(QStringLiteral("LogWindow"));
        LogWindow->resize(400, 393);
        centralWidget = new QWidget(LogWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        testConnectStairsButton = new QPushButton(centralWidget);
        testConnectStairsButton->setObjectName(QStringLiteral("testConnectStairsButton"));
        testConnectStairsButton->setGeometry(QRect(0, 20, 391, 27));
        stairsHost = new QLineEdit(centralWidget);
        stairsHost->setObjectName(QStringLiteral("stairsHost"));
        stairsHost->setGeometry(QRect(10, 0, 251, 20));
        stairsPort = new QLineEdit(centralWidget);
        stairsPort->setObjectName(QStringLiteral("stairsPort"));
        stairsPort->setGeometry(QRect(310, 0, 81, 20));
        logs = new QTableView(centralWidget);
        logs->setObjectName(QStringLiteral("logs"));
        logs->setGeometry(QRect(0, 50, 391, 161));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(0, 240, 391, 111));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 20, 31, 16));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 50, 47, 13));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(280, 70, 100, 41));
        manual_timestamp = new QDateTimeEdit(groupBox);
        manual_timestamp->setObjectName(QStringLiteral("manual_timestamp"));
        manual_timestamp->setGeometry(QRect(80, 80, 194, 22));
        manual_hwdid = new QLineEdit(groupBox);
        manual_hwdid->setObjectName(QStringLiteral("manual_hwdid"));
        manual_hwdid->setGeometry(QRect(80, 50, 113, 20));
        manual_rfid = new QLineEdit(groupBox);
        manual_rfid->setObjectName(QStringLiteral("manual_rfid"));
        manual_rfid->setGeometry(QRect(80, 20, 113, 20));
        sendStampButton = new QPushButton(groupBox);
        sendStampButton->setObjectName(QStringLiteral("sendStampButton"));
        sendStampButton->setGeometry(QRect(264, 10, 111, 41));
        queue = new QCheckBox(centralWidget);
        queue->setObjectName(QStringLiteral("queue"));
        queue->setGeometry(QRect(90, 220, 301, 17));
        LogWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(LogWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        LogWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(LogWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        LogWindow->setStatusBar(statusBar);

        retranslateUi(LogWindow);

        QMetaObject::connectSlotsByName(LogWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LogWindow)
    {
        LogWindow->setWindowTitle(QApplication::translate("LogWindow", "Events", 0));
        testConnectStairsButton->setText(QApplication::translate("LogWindow", "Test Connection to Stairs", 0));
        stairsHost->setText(QApplication::translate("LogWindow", "127.0.0.1", 0));
        stairsPort->setText(QApplication::translate("LogWindow", "8999", 0));
        groupBox->setTitle(QApplication::translate("LogWindow", "Manual Input", 0));
        label->setText(QApplication::translate("LogWindow", "RFID", 0));
        label_2->setText(QApplication::translate("LogWindow", "Hwd ID", 0));
        label_3->setText(QApplication::translate("LogWindow", "<html><head/><body><p>Time Stamp</p></body></html>", 0));
        sendStampButton->setText(QApplication::translate("LogWindow", "Send\n"
"to Stairs", 0));
        queue->setText(QApplication::translate("LogWindow", "Queue on disconnected from stairs?", 0));
    } // retranslateUi

};

namespace Ui {
    class LogWindow: public Ui_LogWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGWINDOW_H
