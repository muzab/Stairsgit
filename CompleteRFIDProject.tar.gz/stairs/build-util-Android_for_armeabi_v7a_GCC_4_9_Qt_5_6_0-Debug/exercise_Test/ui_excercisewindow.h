/********************************************************************************
** Form generated from reading UI file 'excercisewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EXCERCISEWINDOW_H
#define UI_EXCERCISEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ExcerciseWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QLabel *label;
    QComboBox *from_station;
    QLabel *label_2;
    QComboBox *to_station;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *distanceMeters;
    QLineEdit *kcal;
    QPushButton *setRaceButton;
    QGroupBox *groupBox_2;
    QLabel *label_5;
    QComboBox *participant;
    QGroupBox *groupBox_3;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QTableView *sel_statistics;
    QLineEdit *sel_firstname;
    QLineEdit *sel_lastname;
    QLineEdit *sel_numStairs;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ExcerciseWindow)
    {
        if (ExcerciseWindow->objectName().isEmpty())
            ExcerciseWindow->setObjectName(QStringLiteral("ExcerciseWindow"));
        ExcerciseWindow->resize(616, 319);
        centralWidget = new QWidget(ExcerciseWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 0, 191, 261));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 20, 90, 16));
        from_station = new QComboBox(groupBox);
        from_station->setObjectName(QStringLiteral("from_station"));
        from_station->setGeometry(QRect(10, 40, 171, 22));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 70, 90, 13));
        to_station = new QComboBox(groupBox);
        to_station->setObjectName(QStringLiteral("to_station"));
        to_station->setGeometry(QRect(10, 90, 171, 22));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 120, 120, 16));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 170, 90, 13));
        distanceMeters = new QLineEdit(groupBox);
        distanceMeters->setObjectName(QStringLiteral("distanceMeters"));
        distanceMeters->setGeometry(QRect(10, 140, 171, 20));
        kcal = new QLineEdit(groupBox);
        kcal->setObjectName(QStringLiteral("kcal"));
        kcal->setGeometry(QRect(10, 190, 171, 20));
        setRaceButton = new QPushButton(groupBox);
        setRaceButton->setObjectName(QStringLiteral("setRaceButton"));
        setRaceButton->setGeometry(QRect(10, 230, 171, 23));
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(200, 0, 411, 261));
        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 20, 100, 16));
        participant = new QComboBox(groupBox_2);
        participant->setObjectName(QStringLiteral("participant"));
        participant->setGeometry(QRect(90, 20, 241, 22));
        groupBox_3 = new QGroupBox(groupBox_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 50, 391, 201));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 20, 120, 16));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(10, 70, 120, 16));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(10, 150, 120, 16));
        sel_statistics = new QTableView(groupBox_3);
        sel_statistics->setObjectName(QStringLiteral("sel_statistics"));
        sel_statistics->setGeometry(QRect(130, 0, 256, 192));
        sel_firstname = new QLineEdit(groupBox_3);
        sel_firstname->setObjectName(QStringLiteral("sel_firstname"));
        sel_firstname->setGeometry(QRect(10, 40, 113, 20));
        sel_lastname = new QLineEdit(groupBox_3);
        sel_lastname->setObjectName(QStringLiteral("sel_lastname"));
        sel_lastname->setGeometry(QRect(10, 90, 113, 20));
        sel_numStairs = new QLineEdit(groupBox_3);
        sel_numStairs->setObjectName(QStringLiteral("sel_numStairs"));
        sel_numStairs->setGeometry(QRect(62, 170, 61, 20));
        ExcerciseWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(ExcerciseWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 616, 21));
        ExcerciseWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ExcerciseWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        ExcerciseWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ExcerciseWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        ExcerciseWindow->setStatusBar(statusBar);

        retranslateUi(ExcerciseWindow);

        QMetaObject::connectSlotsByName(ExcerciseWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ExcerciseWindow)
    {
        ExcerciseWindow->setWindowTitle(QApplication::translate("ExcerciseWindow", "ExcerciseWindow", 0));
        groupBox->setTitle(QApplication::translate("ExcerciseWindow", "Race Set up", 0));
        label->setText(QApplication::translate("ExcerciseWindow", "Start Station", 0));
        label_2->setText(QApplication::translate("ExcerciseWindow", "End Station", 0));
        label_3->setText(QApplication::translate("ExcerciseWindow", "Distance in Meters", 0));
        label_4->setText(QApplication::translate("ExcerciseWindow", "K Calories", 0));
        setRaceButton->setText(QApplication::translate("ExcerciseWindow", "Set This Race", 0));
        groupBox_2->setTitle(QApplication::translate("ExcerciseWindow", "Race Follow up", 0));
        label_5->setText(QApplication::translate("ExcerciseWindow", "Participant", 0));
        groupBox_3->setTitle(QApplication::translate("ExcerciseWindow", "Selected Person", 0));
        label_6->setText(QApplication::translate("ExcerciseWindow", "First Name", 0));
        label_7->setText(QApplication::translate("ExcerciseWindow", "Last Names", 0));
        label_8->setText(QApplication::translate("ExcerciseWindow", "Number of Stairs", 0));
    } // retranslateUi

};

namespace Ui {
    class ExcerciseWindow: public Ui_ExcerciseWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EXCERCISEWINDOW_H
