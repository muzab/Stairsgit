#include "m_hardware.h"

#include <QDebug>

#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>

#include <QDataStream>

m_hardware::m_hardware(QObject *parent) : QObject(parent)
{
}

void m_hardware::registerStation(const QString &hwd_id,
                                 const QString &description) {
    QSqlQuery qry;
    qry.prepare("insert into station(hwd_id, description)"
                " values(:hwd_id,:description)");
    qry.bindValue(":hwd_id", hwd_id);
    qry.bindValue(":description", description);
    if(!qry.exec())
//        qFatal("Unable to do Insert nto the station table");
        qWarning() << "Duplicate entry" ;

//    emit
}

void m_hardware::registerRFID(const QString &rfid_tag,
                              const QString &firstname,
                              const QString &lastname) {
    QSqlQuery qry;
    qry.prepare("insert into user(firstname, lastname, rfid_ID)"
                " values(:firstname,:lastname, :rfid_tag)");
    qry.bindValue(":firstname", firstname);
    qry.bindValue(":lastname", lastname);
    qry.bindValue(":rfid_tag", rfid_tag);
    if(!qry.exec())
        qFatal("Unable to do Insert nto the user table");

    qry.prepare("insert into stairs(emp_firstname, emp_lastname, rfid_tag)"
                " values(:firstname,:lastname, :rfid_tag)");
    qry.bindValue(":firstname", firstname);
    qry.bindValue(":lastname", lastname);
    qry.bindValue(":rfid_tag", rfid_tag);
    if(!qry.exec())
        qWarning("Warning - Duplicate entries have been discarded");

//    emit
}

void m_hardware::registerConditions(const QString &hwd_id_from,
                                    const QString &hwd_id_to,
                                    const float distanceMeters,
                                    const float kcal) {
    QSqlQuery qry;
    qry.prepare("select station_id from station where hwd_id = :hwd");
    qry.bindValue(":hwd", hwd_id_from);
    if(!qry.exec())
        qFatal("Unable to do Select stations");

    if(!qry.next()) {
        qWarning("Hardware not registerd ");
        return;
    }
    int from_station = qry.value(0).toInt();

    qry.prepare("select station_id from station where hwd_id = :hwd");
    qry.bindValue(":hwd", hwd_id_to);
    if(!qry.exec())
        qFatal("Unable to do Select stations");

    if(!qry.next()) {
        qWarning("Hardware not registerd ");
        return;
    }
    int to_station = qry.value(0).toInt();

    qry.prepare("insert into distance(from_station, to_station, distanceMeters, kcal)"
                " values(:from_station,:to_station,:distanceMeters,:kcal)");
    qry.bindValue(":from_station", from_station);
    qry.bindValue(":to_station", to_station);
    qry.bindValue(":distanceMeters", distanceMeters);
    qry.bindValue(":kcal", kcal);
    if(!qry.exec())
        qFatal("Unable to do Insert nto the distance table");

//    emit
}

void m_hardware::getAllStations() {
    data.clear();
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);

    QSqlQuery qry;
    qry.prepare("select hwd_id, description from station");
    if(!qry.exec())
        qFatal("Unable to do Select on all stations");
    while(qry.next()) {
        stream << qry.value(0).toString();
        stream << qry.value(1).toString();

    }
    emit bufferResponse(data);
}

void m_hardware::getAllRfids() {
    data.clear();
    QDataStream stream(&data, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_0);

    QSqlQuery qry;
    qry.prepare("select rfid_ID, firstname, lastname from user");
    if(!qry.exec())
        qFatal("Unable to do Select on all participants");
    while(qry.next()) {
        stream << qry.value(0).toString();
        stream << qry.value(1).toString();
        stream << qry.value(2).toString();
    }

    emit bufferResponse(data);
}
