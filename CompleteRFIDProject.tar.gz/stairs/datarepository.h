#ifndef MAPPLICATION_H
#define MAPPLICATION_H

#include <QApplication>
#include <QSqlDatabase>
#include <QTableView>
#include <QSqlTableModel>
#include <QTimer>

class DataRepository : public QApplication
{
    Q_OBJECT

public:
    explicit DataRepository(int argc, char *argv[]);
    virtual ~DataRepository();

    void startDb();    

signals:
    void connectedToDB(const QSqlDatabase &db);

private:
    void createTables();
    QSqlDatabase m_db;
};

class tableUpdate : public QTimer {
  Q_OBJECT
public:
  explicit tableUpdate(QObject *parent = 0) : QTimer(parent)
  {
    connect(this, SIGNAL(timeout()), this, SLOT(display()));
  }

//    virtual ~tableUpdate();

private slots:
  void display() {
      QTableView tableView;
      QSqlTableModel tableModel;
      tableModel.setTable("timestamp");
      tableModel.select();
      tableView.setModel(&tableModel);
      tableView.setWindowTitle("’timestamp’ table");
      tableView.show();
  }
};
#endif // MAPPLICATION_H
