#ifndef STAIRPROTOCOLL_H
#define STAIRPROTOCOLL_H

#include <QString>
#include <QDateTime>

///
/// TODO - Do something smart
///
///
enum /*class*/ MessageType /*: quint16*/
{
    PING =          0x00,

    ADD_STATION =   0x01,
    ADD_RFID =      0x02,
    ADD_DISTANCE =  0x03,
    ADD_STAMP =     0x04,    

    DEL_ALL_DISTANCES =  0x10,

    REQUEST_STATIONS =  0x20,
    REQUEST_RFIDS =     0x21,
    REQUEST_STATION1_DATA = 0X22,
    REQUEST_STATION2_DATA = 0X23,

    REQUEST_PERSONAL_RACES =    0x51,

    ALL_STATIONS =          0x70,
    ALL_RFIDS =             0x71,
    ALL_PERSONAL_RACES =    0x72,
    SUBMIT_STATION1_DATA = 0X73,
    SUBMIT_STATION2_DATA = 0X74,
};

struct msg_station1data{
        QString stationID;
        QString rf_id;
        QString start_timestamp;

};

struct msg_station2data{
    QString stationID;
    QString rf_id;
    QString stop_timestamp;

};

struct msg_station {
    QString hwd_id;
    QString description;
};

struct msg_rfid {
  QString rfid_tag;
  QString firstname;
  QString lastname;
};

struct msg_race {
  QString from_station;
  QString to_station;
  float distance;
  float kcal;
  float minutes;
};


#endif // STAIRPROTOCOLL_H
