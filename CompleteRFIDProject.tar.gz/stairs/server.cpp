#include "server.h"
//#include "serverthread.h"

#include <QTcpSocket>
#include <QIODevice>
#include <QBuffer>
#include <QDataStream>

#include "stairprotocol.h"
#include <QDateTime>

Server::Server(QObject *parent) : QTcpServer(parent)
{
    connect(this,
            &QTcpServer::newConnection,
            this,
            &Server::handleRequestOneAtATime);
    this->listen(QHostAddress::Any, 8999);
}

void Server::handleRequestOneAtATime() // Single threaded version
{
    dataSize = 0;
    socket = nextPendingConnection();
    connect(socket,
            &QAbstractSocket::disconnected,
            socket,
            &QObject::deleteLater);
    connect(socket,
            static_cast<void (QTcpSocket::*)(QAbstractSocket::SocketError)>(&QTcpSocket::error),
            this,
            &Server::tcpError);
    connect(socket,
            &QTcpSocket::readyRead,
            this,
            &Server::tcpReady);
}

void Server::tcpReady() {
    QDataStream stream(socket);
    stream.setVersion(QDataStream::Qt_4_0);
    if(dataSize == 0) {
        if(socket->bytesAvailable() < (qint64)sizeof(quint32))
            return;
        stream >> dataSize;
    }
    if(dataSize > socket->bytesAvailable())
        return;
    quint16 mt;
    stream >> mt;
    MessageType typ = static_cast<MessageType>(mt);
    switch(typ)
    {
        case PING:
            break;

        case ADD_STAMP: {
            QString hwd_id, rfid_tag, stamp;
//            QDateTime stamp;
            stream >> hwd_id;
            stream >> rfid_tag;
            stream >> stamp;
//            emit add_stamp(hwd_id, rfid_tag, stamp);
            emit add_station1_data(hwd_id, rfid_tag, stamp);
            qDebug() <<"rfid_tag = "<<rfid_tag;
            qDebug() <<"stamp = "<<stamp;
        }
        break;

        case SUBMIT_STATION1_DATA:
        {
            QString hwd_id, rfid_tag, start_stamp;
            stream >> hwd_id;
            stream >> rfid_tag;
            stream >> start_stamp;

            emit add_station1_data(hwd_id, rfid_tag, start_stamp);
            qDebug() <<"rfid_tag = "<<rfid_tag;
            qDebug() <<"start_stamp = "<<start_stamp;
        }
        break;

        case SUBMIT_STATION2_DATA:
        {
            QString hwd_id, rfid_tag, stop_stamp;
            stream >> hwd_id;
            stream >> rfid_tag;
            stream >> stop_stamp;

            emit add_station2_data(hwd_id, rfid_tag, stop_stamp);
            qDebug() <<"stop_stamp = "<<stop_stamp;
        }
        break;

    case ADD_STATION: {
            QString hwd_id, description;
            stream >> hwd_id;
            stream >> description;
            emit add_station(hwd_id, description);
        }
        break;
    case ADD_RFID: {
            QString rfid_tag, firstname, lastname;
            stream >> rfid_tag;
            stream >> firstname;
            stream >> lastname;
            emit add_rfid(rfid_tag, firstname, lastname);
            qDebug() <<"rfid_tag = "<<rfid_tag;
            qDebug() <<"firstname = "<<firstname;
        }
        break;
    case ADD_DISTANCE: {
            QString from_station, to_station;
            float distanceMeters, kcal;
            stream >> from_station;
            stream >> to_station;
            stream >> distanceMeters;
            stream >> kcal;
            emit add_distance(from_station, to_station, distanceMeters, kcal);
        }
        break;
    case DEL_ALL_DISTANCES: {
            emit delete_all_distances();
        }
        break;

    case REQUEST_STATION1_DATA:
        msgResponsetype = SUBMIT_STATION1_DATA;
        emit completeData_needStation1Data();
        return;
        break;

    case REQUEST_STATION2_DATA:
        msgResponsetype = SUBMIT_STATION2_DATA;
        emit completeData_needStation2Data();
        return;
        break;

    case REQUEST_STATIONS:
        msgResponsetype = ALL_STATIONS;
        emit completeData_needAllStations();
        return; // dont close the socket
        break;
    case REQUEST_RFIDS:
        msgResponsetype = ALL_RFIDS;
        emit completeData_needAllRfid();
        return; // dont close the socket
        break;
    case ALL_PERSONAL_RACES:
        msgResponsetype = ALL_PERSONAL_RACES;
        {
            int personId;
            stream >> personId;
            emit completeData_needAllRaces(personId);
        }
        return; // dont close the socket
        break;
    default:
        break;
    }
    socket->close();
}

void Server::dataCompletedAsRequested(const QByteArray &data) {
    msg.clear(); // start with a clean slate
    // Send the size for all the stream
    QByteArray preData;
    QDataStream preStream(&preData, QIODevice::WriteOnly);
    preStream.setVersion(QDataStream::Qt_4_0);
    preStream << (quint32) data.length();
    preStream << (quint16)msgResponsetype;
    msg.append(preData);
    msg.append(data);
    socket->write(msg);
    socket->close();
}

void Server::tcpError(QAbstractSocket::SocketError error) {
    if(error != QAbstractSocket::RemoteHostClosedError)
        qDebug() << tr("TCP error: %1").arg(socket->errorString());
}
