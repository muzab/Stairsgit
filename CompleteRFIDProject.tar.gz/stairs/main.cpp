#include <QApplication>
#include <QSqlDatabase>
#include <QTableView>
#include <QSqlTableModel>
#include <QTimer>

#include "m_hardware.h"
#include "datarepository.h"
#include "m_participants.h"
#include "m_timestamps.h"
#include "server.h"

int main(int argc, char *argv[])
{
    DataRepository app(argc, argv);
//    tableUpdate tim;
    m_participants *participants = new m_participants(&app);
    m_timestamps *station1data = new m_timestamps(&app);
    m_timestamps *station2data = new m_timestamps(&app);
    m_hardware *hardware = new m_hardware(&app);

    app.connect(&app,
            &DataRepository::connectedToDB,
            participants,
            &m_participants::setDB);
    app.connect(&app,
            &DataRepository::connectedToDB,
            station1data,
            &m_timestamps::setDB);
    app.connect(&app,
            &DataRepository::connectedToDB,
            hardware,
            &m_hardware::setDB);

    app.startDb();
    Server server(&app);

/* For Station-1 */
    app.connect(&server,
            &Server::add_station1_data,
            station1data,
            &m_timestamps::setStation1Data);
    app.connect(&server,
            &Server::completeData_needStation1Data,
            station1data,
            &m_timestamps::getStation1Data);
    app.connect(station1data,
            &m_timestamps::bufferResponse,
            &server,
            &Server::dataCompletedAsRequested
            );

/* For Station-2 */
    app.connect(&server,
                &Server::add_station2_data,
                station2data,
                &m_timestamps::setStation2Data);
    app.connect(&server,
                &Server::completeData_needStation2Data,
                station2data,
                &m_timestamps::getStation2Data);
    app.connect(station2data,
                &m_timestamps::bufferResponse,
                &server,
                &Server::dataCompletedAsRequested
                );


    app.connect(&server,
            &Server::add_rfid,
            hardware,
            &m_hardware::registerRFID);
    app.connect(&server,
            &Server::add_station,
            hardware,
            &m_hardware::registerStation);
    app.connect(&server,
            &Server::add_distance,
            hardware,
            &m_hardware::registerConditions);   

    app.connect(&server,
            &Server::completeData_needAllStations,
            hardware,
            &m_hardware::getAllStations);
    app.connect(&server,
            &Server::completeData_needAllRfid,
            hardware,
            &m_hardware::getAllRfids);
    app.connect(&server,
            &Server::completeData_needAllRaces,
            participants,
            &m_participants::getAllRaces);

    app.connect(hardware,
            &m_hardware::bufferResponse,
            &server,
            &Server::dataCompletedAsRequested
            );
    app.connect(participants,
            &m_participants::bufferResponse,
            &server,
            &Server::dataCompletedAsRequested
            );

    QTableView tableView;
    QSqlTableModel tableModel;
    tableModel.setTable("Station1");
    tableModel.select();
    tableView.setModel(&tableModel);
    tableView.setWindowTitle("’Station-1’ table");
    tableView.show();

//   tim.start(1000);

//    tableUpdate update;
//    update.start(1000);
//    QQmlApplicationEngine engine;
//    engine.load(QUrl(QStringLiteral("qrc:///main.qml")));

    return app.exec();
}



