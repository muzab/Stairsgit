#ifndef NETWORK_MESSAGE_H
#define NETWORK_MESSAGE_H

#include <QString>
#include <QDateTime>
#include <QDataStream>

#include "stairprotocol.h"

class network_message: public QObject
{
    Q_OBJECT

public:
    explicit network_message(QObject *parent,
                             const MessageType typ,
                             const QList<msg_station> &allStations); // message_get_all_station
    explicit network_message(QObject *parent,
                             const MessageType typ,
                             const QList<msg_rfid> &allRfids);   // message_get_all_rfids
    explicit network_message(QObject *parent,
                             const MessageType typ,
                             const QList<msg_race> &allTimes);   // message_get_races_of

    void out(QDataStream &outStream);
    int sz() const;

signals:

public slots:

private:
    QByteArray data;
    QDataStream stream;
};

#endif // NETWORK_MESSAGE_H
