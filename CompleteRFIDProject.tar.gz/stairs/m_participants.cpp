#include "m_participants.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QIODevice>
#include <QDataStream>

m_participants::m_participants(QObject *parent)
    : QObject( parent ), m_db(NULL)
{
}

 void m_participants::setDB(const QSqlDatabase &db) {
     m_db = &db;
     QSqlQuery qry;
     qry.prepare("select ID from user");// Should be only the ones with data
     if(!qry.exec())
         qFatal("Unable to do Select");

     while(qry.next())
         emit newParticipant(qry.value(0).toInt());
 }

 void m_participants::getAllRaces(const int personUID) {
     data.clear();
     QDataStream stream(&data, QIODevice::WriteOnly);
     stream.setVersion(QDataStream::Qt_4_0);

     QSqlQuery qry;
     qry.prepare("select station_id, stamp from timestamp where participant_id = :uid");
     qry.bindValue(":uid", personUID);
     if(!qry.exec())
         qFatal("Unable to do Select on races from a participants");
     while(qry.next()) {
         stream << qry.value(0).toString();
         stream << qry.value(0).toString();
         stream << (float)1;
         stream << (float)1;
         stream << (float)10;
     }
     emit bufferResponse(data);
 }
