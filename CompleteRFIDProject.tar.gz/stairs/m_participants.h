#ifndef M_PARTICIPANTS_H
#define M_PARTICIPANTS_H

#include <QObject>

class QSqlDatabase;

class m_participants : public QObject
{
    Q_OBJECT

public:
    explicit m_participants(QObject *parent = 0);
    const QList<QString> &participantUIDs() const;

    const QString& getName(const int personUID) const;

signals:
    void newParticipant(const int personUID);
    void bufferResponse(const QByteArray &data);

public slots:
    void setDB(const QSqlDatabase &db);
    void getAllRaces(const int personUID);

private:
    const QSqlDatabase *m_db;
    QByteArray data;
};

#endif // M_PARTICIPANTS_H
