#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QAbstractSocket>
#include <QByteArray>

#include "stairprotocol.h" // TODO take this dependency

class QTcpSocket;

class Server : public QTcpServer
{
    Q_OBJECT

public:
    explicit Server(QObject *parent);

signals:
    void add_stamp(const QString &hwd_id,
                   const QString &rfid_tag,
                   const QDateTime &stamp);
    void add_station(const QString &hwd_id,
                     const QString &description);
    void add_rfid(const QString &rfid_tag,
                  const QString &firstname,
                  const QString &lastname);
    void add_distance(const QString &from_station,
                      const QString &to_station,
                      const float distanceMeters,
                      const float kcal);
    void add_station1_data(const QString &station1ID,
                           const QString &emp_rfid,
                           const QString &start_time);
    void add_station2_data(const QString &station2ID,
                           const QString &emp_rfid,
                           const QString &stop_time);

    void delete_all_distances();

    void completeData_needStation1Data();
    void completeData_needStation2Data();
    void completeData_needAllStations();
    void completeData_needAllRfid();
    void completeData_needAllRaces(const int person_id);

public slots:
    void handleRequestOneAtATime();
    void tcpReady();
    void tcpError(QAbstractSocket::SocketError error);
    void dataCompletedAsRequested(const QByteArray &data);

private:
    int dataSize;
    QByteArray msg;
    QTcpSocket* socket;

    MessageType msgResponsetype;
};

#endif // SERVER_H
