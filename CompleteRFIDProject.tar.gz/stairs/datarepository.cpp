#include "datarepository.h"

#include <QDebug>
#include <QSqlError>
#include <QSqlQuery>
#include <QTableView>
#include <QSqlTableModel>

DataRepository::DataRepository(int argc, char *argv[]) :
    QApplication(argc, argv)
{
}

void DataRepository::startDb() {
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(":memory:");
    if(! m_db.open()) {
        qDebug() << m_db.lastError();
        qFatal("No way to share data");
    }
    createTables();
    emit connectedToDB(m_db);
}

DataRepository::~DataRepository() {
    m_db.close();
}

void DataRepository::createTables() {
    QSqlQuery qry;

    qry.prepare("CREATE TABLE IF NOT EXISTS stairs ("
                "emp_id INTEGER PRIMARY KEY,"
                "emp_firstname VARCHAR(15),"
                "emp_lastname VARCHAR(15),"
                "rfid_tag  VARCHAR(20),"
                "start_stamp VARCHAR(25),"
                "stop_stamp VARCHAR(25),"
                "UNIQUE (emp_firstname, emp_lastname, rfid_tag, start_stamp, stop_stamp)"
              ")");

    if(!qry.exec())
        qFatal("Unable to create TABLE stairs");


    qry.prepare("CREATE TABLE IF NOT EXISTS rfid ("
                "ID INTEGER PRIMARY KEY,"
                "value VARCHAR(20),"
                "notes VARCHAR(20)"
              ")");
    if(!qry.exec())
        qFatal("Unable to create TABLE rfid");


    qry.prepare("CREATE TABLE IF NOT EXISTS timestamp ("
                "ID INTEGER PRIMARY KEY,"
                "station_id INTEGER,"
                "participant_rfid VARCHAR(20),"
                "start_stamp VARCHAR(25)"
              ")");

    if(!qry.exec())
        qFatal("Unable to create TABLE timestamp");


    qry.prepare("CREATE TABLE IF NOT EXISTS Station2 ("
                "station_id INTEGER PRIMARY KEY,"
                "participant_rfid VARCHAR(20),"
                "stop_stamp VARCHAR(25),"
                "UNIQUE (participant_rfid, stop_stamp)"
              ")");

    if(!qry.exec())
        qFatal("Unable to create TABLE Station2");


    qry.prepare("CREATE TABLE IF NOT EXISTS user ("
                "ID INTEGER PRIMARY KEY,"
                "firstname VARCHAR(20),"
                "lastname  VARCHAR(20),"
                "rfid_ID  VARCHAR(20),"
                "image_ID  VARCHAR(20),"
                "notes  VARCHAR(50)"
              ")");
    if(!qry.exec())
        qFatal("Unable to create TABLE user");


    qry.prepare("CREATE TABLE IF NOT EXISTS station ("
                "ID INTEGER PRIMARY KEY,"
                "station_name VARCHAR(20),"
                "hwd_id VARCHAR(20),"
                "floor VARCHAR(50),"
                "description  VARCHAR(50),"
                "UNIQUE (hwd_id, description)"
              ")");
    if(!qry.exec())
        qFatal("Unable to create TABLE station");


    qry.prepare("CREATE TABLE IF NOT EXISTS image ("
                "ID INTEGER PRIMARY KEY,"
                "caption VARCHAR(20),"
                "img VARCHAR(20)"
              ")");
    if(!qry.exec())
        qFatal("Unable to create TABLE image");


/*********************************************************************/
/*             New
 *********************************************************************/
    qry.prepare("CREATE TABLE IF NOT EXISTS distance ("
                "from_station   INTEGER,"
                "to_station     INTEGER,"
                "distanceMeters REAL,"
                "kcal           REAL"
              ")");
    if(!qry.exec())
        qFatal("Unable to create TABLE distance");

}


