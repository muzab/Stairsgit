#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QByteArray>
#include <QDateTime>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_Red_Slider_valueChanged(int value);
    void on_Green_Slider_valueChanged(int value);
    void on_Blue_Slider_valueChanged(int value);
    void updateRGB(QString);
    void readSerial();
    void updateRFID(QString);
    void updateStartTime(QString);
    void updateStopTime(QString);

private:
    Ui::MainWindow *ui;


    QSerialPort *raspberrypi;
    static const quint16 raspberrypi_vendor_id = 7531;
    static const quint16 raspberrypi_product_id = 260;
    QString raspberrypi_port_name;
    bool raspberrypi_is_available;

    QSerialPort *arduino;
    static const quint16 arduino_uno_vendor_id = 10755;
    static const quint16 arduino_uno_product_id = 67;
    QString arduino_port_name;
    bool arduino_is_available;

    /* Variables used during Serial-Communication */
    QByteArray serialData;
    QString serialBuffer;
    QString parsed_Data;
    double startTime;
    double stopTime;
    double rfid;    
    int flag;

    /* Variables used during Database Read/Write */

    QString startTime_db;
    QString stopTime_db;
    QDate day;
    QString date;


};

#endif // MAINWINDOW_H
