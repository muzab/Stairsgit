#ifndef MAINCHART_H
#define MAINCHART_H


//#include <QtDeclarative/QDeclarativeItem>
#include <QMainWindow>
#include <QObject>
//#include <QQuickItem>
#include <QSharedDataPointer>
#include <QWidget>


class mainChartData;

class mainChart
{
public:
    mainChart();
    mainChart(const mainChart &);
    mainChart &operator=(const mainChart &);
    ~mainChart();

private:
    QSharedDataPointer<mainChartData> data;
};

#endif // MAINCHART_H
