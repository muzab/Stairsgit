#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSerialPort/QSerialPort>
#include <QIODevice>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QtWidgets>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    qDebug() << "Number of available ports: " << QSerialPortInfo::availablePorts().length();


//    raspberrypi = new QSerialPort;

    /* Serial-Communication with Arduino */
    arduino = new QSerialPort;
    ui->rfid_Number->display("-------");
    ui->start_time->display("-----");
    ui->stop_time->display("-----");
    serialBuffer = "";
    parsed_Data = "";
    rfid = 0.0;
    startTime = 0.0;
    stopTime = 0.0;
    flag = 0;

    /* Database Read-Write */
    day = QDate::currentDate();
    startTime_db = QDateTime::currentDateTime().toString("hh:mm:ss.zzz");
    stopTime_db = QDateTime::currentDateTime().toString("hh:mm:ss.zzz");
    date = day.toString("dd/MM/yyyy");


/*
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
            qDebug() << "Has vendor ID: " << serialPortInfo.hasVendorIdentifier();
            if(serialPortInfo.hasVendorIdentifier()){
                qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier();
            }
            qDebug() << "Has Product ID: " << serialPortInfo.hasProductIdentifier();
            if(serialPortInfo.hasProductIdentifier()){
                qDebug() << "Product ID: " << serialPortInfo.productIdentifier();
            }
     }
*/

    bool arduino_is_available = false;

    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        if(serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier())
        {
            if(serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id)
            {
                if(serialPortInfo.productIdentifier() == arduino_uno_product_id)
                {
                    arduino_port_name = serialPortInfo.portName();
                    arduino_is_available = true;
                }
            }
        }
    }

    if(arduino_is_available)
    {
        //open and configure the serial port
        arduino->setPortName(arduino_port_name);
        arduino->open(QSerialPort::ReadWrite);
        arduino->setBaudRate(QSerialPort::Baud9600);
        arduino->setDataBits(QSerialPort::Data8);
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop);
        arduino->setFlowControl(QSerialPort::NoFlowControl);

        QObject::connect(arduino, SIGNAL(readyRead()), this, SLOT(readSerial()));
    }
    else
    {
        //Error if not found
        QMessageBox::warning(this,"Port Error", "Could't find Arduino");
    }

}

MainWindow::~MainWindow()
{
    if(arduino->isOpen())
    {
        arduino->close();
    }

    delete ui;
}

void MainWindow::on_Red_Slider_valueChanged(int value)
{
    ui->Red_Value->setText(QString("<span style=\" font-size:9pt; font-weight:600;\">%1</span>").arg(value));
    MainWindow::updateRGB(QString("r%1").arg(value));
    qDebug() <<value;

}

void MainWindow::on_Green_Slider_valueChanged(int value)
{
    ui->Green_Value->setText(QString("<span style=\" font-size:9pt; font-weight:600;\">%1</span>").arg(value));
    MainWindow::updateRGB(QString("g%1").arg(value));
    qDebug() <<value;
}

void MainWindow::on_Blue_Slider_valueChanged(int value)
{
    ui->Blue_Value->setText(QString("<span style=\" font-size:9pt; font-weight:600;\">%1</span>").arg(value));
    MainWindow::updateRGB(QString("b%1").arg(value));
    qDebug() <<value;

}


void MainWindow::updateRGB(QString command)
{
    if(arduino->isWritable())
    {
        arduino->write(command.toStdString().c_str());
    }
    else
    {
        qDebug() <<"Couldn't write to serial";
    }
}



void MainWindow::readSerial()
{
    QStringList buffer_split = serialBuffer.split(";");

    if(buffer_split.length()<4)
    {
        serialData = arduino->readAll();
        serialBuffer = serialBuffer + QString::fromStdString(serialData.toStdString());
        serialData.clear();
    }
    else
    {
        serialBuffer = "";
        qDebug() <<QDateTime::currentDateTime().toString("hh:mm:ss.zzz")<<endl;
        qDebug() <<"Buffer Split ="<<buffer_split<<endl;

        rfid = (buffer_split[0]).toDouble();;
        startTime = (buffer_split[1]).toDouble();
        stopTime = (buffer_split[2]).toDouble();
        qDebug() <<"RFID = "<<rfid<<endl;
        qDebug() <<"Start Time = "<<startTime<<endl;
        qDebug() <<"Stop Time = "<<stopTime<<endl;

        QFile file("data.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Append))
            return;

        QTextStream out(&file);
        out <<"Date: "<<date<<" RFID: " << rfid+(flag++) <<" Start Time: "<<startTime_db<<" Stop Time: "<<stopTime_db<<"\n";

        MainWindow::updateRFID(QString::number(rfid+(flag++),'g',4));
        MainWindow::updateStartTime(QString::number(startTime+(flag++),'g',4));
        MainWindow::updateStopTime(QString::number(stopTime+(flag++),'g',4));
    }
}

void MainWindow::updateRFID(QString rfid_value)
{
   ui->rfid_Number->display(rfid_value);
}

void MainWindow::updateStartTime(QString start_time_value)
{
    ui->start_time->display(start_time_value);
}

void MainWindow::updateStopTime(QString stop_time_value)
{
    ui->stop_time->display(stop_time_value);
}
