#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setFixedSize(500,325);
    w.setWindowTitle("Arduino/Beaglebone Controller");
    w.show();

    return a.exec();
}
